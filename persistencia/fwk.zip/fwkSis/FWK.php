<?php
require_once "../dao/Conexao.php";

class FWK
{
    private $conn;
    public function conexao()
    {
        $this->conn=Conexao::conectar();
    }
    function selecionarBanco(){
        $sql="select database()";
        $query=$this->conn->query($sql);
        $banco=$query->fetch();
        return $banco[0];
    }
    function selecionarTabela($t){
        $banco="Tables_in_".$this->selecionarBanco();
        $t1=strtoupper($t);
        $sql="Show tables";
        $query=$this->conn->query($sql);
        $tabelas=$query->fetchAll(PDO::FETCH_OBJ);
        foreach ($tabelas as $tabela) {
            $t2=strtoupper($tabela->$banco);
            if(strcmp($t1,$t2)==0)
                return $tabela->$banco;
        }

    }
    function selecionarColunas($tabela){

        $sql="Show columns from ".$tabela;
        $query=$this->conn->query($sql);
        $colunas=$query->fetchAll(PDO::FETCH_OBJ);
        $txt="";
        foreach ($colunas as $coluna){
            $txt.=$coluna->Field.",";
        }
        $txt=substr($txt,0,-1);
        return $txt;


    }
    function salvar($obj)
    {
        $this->conexao();
       $tabela = $this->selecionarTabela(get_class($obj));
       $colunas= $this->selecionarColunas($tabela);
       $raca=$obj->getRaca();
       $peso=$obj->getPeso();
       $tam=$obj->getTamanho();
       $sql= "insert into ".$tabela." (".$colunas.") values(null,'$raca','$tam','$peso')";
       $stmt = $this->conn->prepare($sql);
       $stmt->execute();
        echo $sql;


    }
}