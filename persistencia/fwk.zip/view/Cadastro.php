<?php
include "../fwkSis/FWK.php";
include "../model/Pessoas.php";
include "../model/Animal.php";


$fwk=new FWK();

 $a= new Animal();
 $a->setRaca("Vira latas");
 $a->setPeso(3);
 $a->setTamanho(10);
$fwk->salvar($a);

